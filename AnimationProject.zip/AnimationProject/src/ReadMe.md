
A read me file is great for unconventionally ran projects. 
This project does not have a method called Main.java, so some directions are helpful for a future user.

(If you want to make a newline in a read me file, you type two spaces and one enter.)

(Another way is to add the the HTML br symbol. <br> 
Which looks like < b r > without spaces.)

Read me files tend to have a lot of extra text in them that most people skip reading. 
Often the directions for how to run a program are the bottom of a read me file.

We will be using the word SPRITE a lot in this presentation. 

A **computer graphic sprite** is a series of images that show a character in different motions.
When ran through quickly, the image array of sprites make it look like the character is moving.
The origin of the word for the computer graphic sprite comes from the latin word "spiritus" meaning spirit
then connecting to the Old French word "esprit."

The **atmospheric sprite** that is a cluster of red flashes that comes after lightning and
is connected to the folklore of spirits from which the computer graphic sprite was developed. 
The computer graphic sprite word came before atmospheric sprite.
Red sprites were discovered in 1989.

See the sprite.png in the imagesAWT folder.

FOR COMMENTS ON HOW THE PROJECT WORKS: 
See the MainMenu.java and Stingray.java files which are completely annotated with comments.  
You can get some insight for how to using two sprites at once by reviewing theLionParrot()  
constructor and run() method in the LionParrot.java.

HOW TO RUN THIS PROJECT:

To run this project as designed,  
please go to the MenuPackages package  
open MainMenu.java class  
click the run button.

If clicking the run button  does not work,  
click the drop down run menu and  
select the MainMenu option.


This project is designed to run on Java SE 23 using a Java Eclipse compiler.


