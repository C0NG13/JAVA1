package MenuPackages;
import javax.swing.*;

import AnimationPackages.LionParrot;
import AnimationPackages.Parrot;
import AnimationPackages.Stingray;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class SpecialFeatures extends JFrame {

    private BufferedImage backgroundImage;
    private Font largeFont = new Font("SansSerif", Font.BOLD, 36); 
    private Font titleFont = new Font("SansSerif", Font.BOLD, 70);

    public SpecialFeatures() {
    	dispose();
        
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);

        try {
            backgroundImage = ImageIO.read(getClass().getResource("/MenuImages/SpecialFeatures.png"));
        } catch (Exception e) {
            System.err.println("Error loading background image: " + e.getMessage());
            backgroundImage = null;
        }

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };

        panel.setLayout(new GridBagLayout());
        panel.setOpaque(false);
        
        JLabel titleLabel = new JLabel("Directional Multiple Character Movement"); 
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(Color.getHSBColor(30/360f, 1f, 1f)); 
        GridBagConstraints titleGbc = new GridBagConstraints();
        titleGbc.gridx = 0;
        titleGbc.gridy = 0;
        titleGbc.insets = new Insets(20, 0, 20, 0); 
        panel.add(titleLabel, titleGbc);

        JLabel episodesLabel = createClickableLabel("Parrot Flying the Other Way");
        JLabel specialFeaturesLabel = createClickableLabel("Parrot and Puma");
       
        JLabel exitLabel = createClickableLabel("Main Menu");

        episodesLabel.setFont(largeFont); 
        specialFeaturesLabel.setFont(largeFont);
        
        exitLabel.setFont(largeFont);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;

        JPanel topSpacer = new JPanel();
        topSpacer.setOpaque(false);
        topSpacer.setPreferredSize(new Dimension(1, 50));
        panel.add(topSpacer, gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 0, 10, 0);

        panel.add(episodesLabel, gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 2; gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(specialFeaturesLabel, gbc);



        gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 4; gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(exitLabel, gbc);

        add(panel);

        setVisible(true);
    }

    private JLabel createClickableLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                label.setForeground(Color.getHSBColor(50/360f, 1f, 1f)); 
            }

            @Override
            public void mouseExited(MouseEvent e) {
                label.setForeground(Color.WHITE); 
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                handleLabelClick(text);
            }
        });

        return label;
    }

    private void handleLabelClick(String text) {
        switch (text) {
            case "Parrot Flying the Other Way":
            	Parrot animation0 = new Parrot("title");
                animation0.setVisible(true);
                
                System.out.println("Feature 1 clicked.");
                break;
            case "Parrot and Puma":
            	LionParrot animation1 = new LionParrot("title");
                animation1.setVisible(true);
                System.out.println("Feature 2 clicked.");
                break;
            case "Main Menu":
                MainMenu menu = new MainMenu();
                menu.setVisible(true);
                //dispose(); 
                break;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SpecialFeatures());
    }
}