package MenuPackages;
import javax.swing.*;

import AnimationPackages.PenguinBuffered;
import AnimationPackages.PenguinNotBuffered;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class SetUp extends JFrame {

    private BufferedImage backgroundImage;
    private Font largeFont = new Font("SansSerif", Font.BOLD, 36); 
    private Font titleFont = new Font("SansSerif", Font.BOLD, 70);

    public SetUp() {
    	dispose();
        
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);

        try {
            backgroundImage = ImageIO.read(getClass().getResource("/MenuImages/SetUp.jpg"));
        } catch (Exception e) {
            System.err.println("Error loading background image: " + e.getMessage());
            backgroundImage = null;
        }

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };

        panel.setLayout(new GridBagLayout());
        panel.setOpaque(false);
        
        JLabel titleLabel = new JLabel("Buffering with AWT"); 
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(Color.CYAN); 
        GridBagConstraints titleGbc = new GridBagConstraints();
        titleGbc.gridx = 0;
        titleGbc.gridy = 0;
        titleGbc.insets = new Insets(20, 0, 20, 0); 
        panel.add(titleLabel, titleGbc);

        JLabel episodesLabel = createClickableLabel("Jumping Penguin Buffered");
        JLabel specialFeaturesLabel = createClickableLabel("Jumping Penguin Not Buffered");
        
        JLabel exitLabel = createClickableLabel("Main Menu");

        episodesLabel.setFont(largeFont); // Set the font for each label
        specialFeaturesLabel.setFont(largeFont);
        
        exitLabel.setFont(largeFont);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;

        JPanel topSpacer = new JPanel();
        topSpacer.setOpaque(false);
        topSpacer.setPreferredSize(new Dimension(1, 50));
        panel.add(topSpacer, gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 0, 10, 0);

        panel.add(episodesLabel, gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 2; gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(specialFeaturesLabel, gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 4; gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(exitLabel, gbc);

        add(panel);

        setVisible(true);
    }

    private JLabel createClickableLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                label.setForeground(Color.getHSBColor(50/360f, 1f, 1f)); 
            }

            @Override
            public void mouseExited(MouseEvent e) {
                label.setForeground(Color.WHITE); 
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                handleLabelClick(text);
            }
        });

        return label;
    }
    MainMenu menu = new MainMenu();
    private void handleLabelClick(String text) {
        switch (text) {
	        case "Jumping Penguin Buffered":
	        	PenguinBuffered animation0 = new PenguinBuffered("title");
	        	animation0.setVisible(true);
	        	
	            System.out.println("Episode 1 clicked.");
	        	
	
	            break;
	        case "Jumping Penguin Not Buffered":
	        	PenguinNotBuffered animation1 = new PenguinNotBuffered("title");
	            animation1.setVisible(true);
	            
	            System.out.println("Episode 2 clicked.");
	            break;
            
            case "Main Menu":
                
                menu.setVisible(true);
                
                break;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SetUp());
    }
}