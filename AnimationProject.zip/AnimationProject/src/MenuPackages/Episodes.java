package MenuPackages;
import javax.swing.*;
import AnimationPackages.Lion;
import AnimationPackages.Stingray;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;



@SuppressWarnings("serial")
public class Episodes extends JFrame {

	private static final long serialVersionUID = 1L;
	private BufferedImage backgroundImage;
    private Font largeFont = new Font("SansSerif", Font.BOLD, 36); 
    private Font titleFont = new Font("SansSerif", Font.BOLD, 70);

    public Episodes() {
    	dispose();
        
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);

        try {
        	backgroundImage = ImageIO.read(getClass().getResource("/MenuImages/Episodesbg.png"));
            
        } catch (Exception e) {
            System.err.println("Error loading background image: " + e.getMessage());
            backgroundImage = null;
        }


		JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };

        panel.setLayout(new GridBagLayout());
        panel.setOpaque(false);
        
        
        JLabel titleLabel = new JLabel("Movement"); 
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(Color.getHSBColor(20/360f, 0.8f, 0.9f)); 
        GridBagConstraints titleGbc = new GridBagConstraints();
        titleGbc.gridx = 0;
        titleGbc.gridy = 0;
        titleGbc.insets = new Insets(20, 0, 20, 0); 
        panel.add(titleLabel, titleGbc);
        

        JLabel episodesLabel = createClickableLabel("Running Puma");
        JLabel setupLabel = createClickableLabel("Swimming Stingray");
        JLabel exitLabel = createClickableLabel("Main Menu");

        episodesLabel.setFont(largeFont); 
        
        setupLabel.setFont(largeFont);
        exitLabel.setFont(largeFont);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;

        JPanel topSpacer = new JPanel();
        topSpacer.setOpaque(false);
        topSpacer.setPreferredSize(new Dimension(1, 50));
        panel.add(topSpacer, gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 0, 10, 0);

        panel.add(episodesLabel, gbc);


        gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 3; gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(setupLabel, gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 4; gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(exitLabel, gbc);

        add(panel);

        setVisible(true);
    }


    private JLabel createClickableLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                label.setForeground(Color.getHSBColor(50/360f, 1f, 1f)); 
            }

            @Override
            public void mouseExited(MouseEvent e) {
                label.setForeground(Color.WHITE); 
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                handleLabelClick(text);
            }
        });

        return label;
    }
    
    private void handleLabelClick(String text) {
        switch (text) {
            case "Running Puma":
            	Lion animation0 = new Lion("title");
            	animation0.setVisible(true);
            	
                System.out.println("Episode 1 clicked.");
            	

                break;
           case "Swimming Stingray":
        	   Stingray animation1 = new Stingray("title");
                animation1.setVisible(true);

                System.out.println("Episode 2 clicked.");
                break;
            case "Main Menu":
                MainMenu menu = new MainMenu();
                menu.setVisible(true);
                //dispose(); 
                break;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Episodes());
    }
}