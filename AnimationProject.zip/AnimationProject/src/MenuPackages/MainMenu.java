
/* Final Project
Alethea Koppe
 CPT 236
I am putting this here because I did not want to rename my project.*/

package MenuPackages;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

@SuppressWarnings("serial") // This is needed here to prevent the serial error. 
// (The serializable class MainMenu does not declare a static final serialVersionUID field of type long.) 
public class MainMenu extends JFrame {

    private BufferedImage backgroundImage;
    private Font largeFont = new Font("SansSerif", Font.BOLD, 36); // font
    private Font titleFont = new Font("SansSerif", Font.BOLD, 70);

    public MainMenu() {
        dispose(); /* The dispose in here prevents the glitchy transition between menu pages.
        We must open the next menu (e.g. Special Features) before closing this menu.
        If we close this menu before opening the next menu, we will get a flashy glitch. */
        
        setExtendedState(JFrame.MAXIMIZED_BOTH); // for the full screen effect in our JFrame
        
        setUndecorated(true); // this removes the 90s frame :)

        try { // While I know this file path works, to prevent an error, I must do a try catch.       	
            backgroundImage = ImageIO.read(getClass().getResource("/MenuImages//Mainbg.png"));
        } catch (Exception e) {
            System.err.println("Error loading background image: " + e.getMessage()); // prints a red error message in the console 
            backgroundImage = null;
        }

        
        /* 
        designing our JPanel 
        Notice that the { }; creates a anonymous subclass.
        Anonymous subclass are used for creating a small one time use of a variation of a method from another class.
        The method we are overriding from the JPanel class is paintComponent(). 
        */
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this); 
                    // gets the size of the JPanel which is the size of the screen ^^^
                }
            }
        };

        panel.setLayout(new GridBagLayout()); // layout used so I can center the menu text
        panel.setOpaque(false); // ensures painting order is followed, i.e. paint the background image, then paint the text.
        
        JLabel titleLabel = new JLabel("Abstract Window Toolkit Animations");  // menu title
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(Color.CYAN); 
        // centering text within each row v v v
        GridBagConstraints titleGbc = new GridBagConstraints();
        titleGbc.gridx = 0;
        titleGbc.gridy = 0;
        titleGbc.insets = new Insets(20, 0, 20, 0); // centers from top and bottom by adding padding above and below
        panel.add(titleLabel, titleGbc);
        

        JLabel episodesLabel = createClickableLabel("Episodes");		// submenu titles
        JLabel specialFeaturesLabel = createClickableLabel("Special Features");
        JLabel setupLabel = createClickableLabel("Set-up");
        JLabel exitLabel = createClickableLabel("Exit");	// option to leave program

        episodesLabel.setFont(largeFont);	// font size
        specialFeaturesLabel.setFont(largeFont);
        setupLabel.setFont(largeFont);
        exitLabel.setFont(largeFont);

        // This next set of code places the menu text for submenues in the center of each row.
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;

        JPanel topSpacer = new JPanel();
        topSpacer.setOpaque(false);
        topSpacer.setPreferredSize(new Dimension(1, 50)); 
        panel.add(topSpacer, gbc);

        gbc = new GridBagConstraints(); 
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(episodesLabel, gbc);						// Episodes

        gbc = new GridBagConstraints();
        gbc.gridx = 0; 
        gbc.gridy = 2; 
        gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(specialFeaturesLabel, gbc);				// Special Features

        gbc = new GridBagConstraints();
        gbc.gridx = 0; 
        gbc.gridy = 3; 
        gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(setupLabel, gbc);							// Set Up

        gbc = new GridBagConstraints();
        gbc.gridx = 0; 
        gbc.gridy = 4; 
        gbc.insets = new Insets(10, 0, 10, 0);
        panel.add(exitLabel, gbc);						    // Exit

        
        add(panel);
        setVisible(true);
    }

    // This makes the menu options turn yellow when the cursor is over that option.
    private JLabel createClickableLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                label.setForeground(Color.getHSBColor(50/360f, 1f, 1f)); // change color on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                label.setForeground(Color.WHITE); // return to original color
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                handleLabelClick(text);
            }
        });

        return label;
    }

    // upon click the next menu is launched
    private void handleLabelClick(String text) {
        switch (text) {
            case "Episodes":
                Episodes episodesMenu = new Episodes();
                episodesMenu.setVisible(true);
                System.out.println("Episodes clicked.");
                break;
            case "Special Features":
                SpecialFeatures features = new SpecialFeatures();
                features.setVisible(true);
                System.out.println("Special Features clicked.");
                break;
            case "Set-up":
                SetUp set = new SetUp();
                set.setVisible(true);
                System.out.println("Set-up clicked.");
                break;
            case "Exit":
            	System.out.println("Exit clicked.");
                System.exit(0);
                break;
        }
    }

    public static void main(String[] args) {
        // Swing is not thread safe. invokeLater() is needed to ensure thread-safe behavior of my code. 
        SwingUtilities.invokeLater(() -> new MainMenu());
        
        /*
        
         Event Dispatch Thread ensures thread safety by preventing:
 				accessing GUI parts in the wrong order
 				GUI crashing or having inconsistencies
 				deadlocks
 		 Event Dispatch Thread also helps with:
 		 		mouse click detection
 		 		for continuous loops (e.g. waiting for that mouse click)
 		
 		 from the SwingUtilities class we use invokeLater()
         
         invokeLater() makes sure that this Swing GUI runs on Event Dispatch Thread 
         		places code in a Event Dispatch Thread que 
 				
         -> is a lambda expression: defines task to be performed
         new MainMenu() instances a new MainMenu object    
             
        */

    }
}