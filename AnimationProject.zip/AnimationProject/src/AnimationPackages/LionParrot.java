package AnimationPackages;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class LionParrot extends Frame implements Runnable {

    private Image backgroundImage;
    private Image[] lionSpriteImages;
    private int currentLionSpriteIndex = 0;
    private int lionSpriteChangeDelay = 200; // milliseconds between lion sprite frames
    private int lionSpriteX;
    private int lionSpriteY;

    private Image[] parrotSpriteImages;
    private int currentParrotSpriteIndex = 0;
    private int parrotSpriteChangeDelay = 150; // milliseconds between parrot sprite frames
    private int parrotSpriteX;
    private int parrotSpriteY;
    private int parrotHoverOffset = 10; // amplitude of the hovering motion
    private double parrotHoverSpeed = 0.1; // speed of the hovering motion
    private double parrotHoverAngle = 0;
    private int parrotRetreatSpeed = 25; // Speed at which the parrot moves off-screen

    private Thread animator;
    private int frameWidth;
    private int frameHeight;
    private GraphicsDevice gd;
    private BufferedImage offScreenBuffer;
    private Graphics offScreenGraphics;

    private int count = 0;
    private boolean parrotRetreating = false;

    // define image paths as String variables
    private String backgroundPath = "src/imagesAWT/parrotbeach.jpeg";
    private String[] lionSpritePaths = {
            "src/imagesAWT/lioness1.png",
            "src/imagesAWT/lioness2.png",
            "src/imagesAWT/lioness3.png",
            "src/imagesAWT/lioness4.png",
            "src/imagesAWT/lioness5.png",
            "src/imagesAWT/lioness6.png",
            "src/imagesAWT/lioness7.png",
            "src/imagesAWT/lioness8.png",
    };
    private String[] parrotSpritePaths = {
            "src/imagesAWT/parrotess1.png",
            "src/imagesAWT/parrotess2.png",
            "src/imagesAWT/parrotess3.png",
            "src/imagesAWT/parrotess4.png",
            "src/imagesAWT/parrotess5.png",
            "src/imagesAWT/parrotess6.png",
            "src/imagesAWT/parrotess7.png",
            "src/imagesAWT/parrotess8.png",
            "src/imagesAWT/parrotess9.png"
    };

    public LionParrot(String title) { 
        super(title);
        try {
            backgroundImage = ImageIO.read(new File(backgroundPath));

            lionSpriteImages = new Image[lionSpritePaths.length]; // iterating thru the sprite image list
            for (int i = 0; i < lionSpritePaths.length; i++) {
                lionSpriteImages[i] = ImageIO.read(new File(lionSpritePaths[i]));
            }

            parrotSpriteImages = new Image[parrotSpritePaths.length];
            for (int i = 0; i < parrotSpritePaths.length; i++) {
                parrotSpriteImages[i] = ImageIO.read(new File(parrotSpritePaths[i]));
            }

        } catch (IOException e) {
            System.err.println("Error loading images: " + e.getMessage());
            System.exit(1);
        }

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        gd = ge.getDefaultScreenDevice(); 
        DisplayMode dm = gd.getDisplayMode(); // gets screen details
        setUndecorated(true);
        setSize(dm.getWidth(), dm.getHeight());
        gd.setFullScreenWindow(this); // make animated display full screen

        frameWidth = dm.getWidth();
        frameHeight = dm.getHeight();
        System.out.println(dm.getHeight());

        // lion's initial position 
        lionSpriteX = frameWidth + 100; // start off-screen to the right
        lionSpriteY = (int) (frameHeight * 0.6); // position at bottom

        // parrot's initial position on the left side
        parrotSpriteX = 50; // start from the left with some offset
        parrotSpriteY = (int) (frameHeight * 0.4); // position towards the middle left

        setVisible(true);

        animator = new Thread(this);
        animator.start();
    }

    public void run() {
        while (count <= 40) { // Increased the loop count to allow time for parrot to move off-screen
            try {
                Thread.sleep(Math.min(lionSpriteChangeDelay, parrotSpriteChangeDelay));
                count++;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }

            // update Lion's animation
            lionSpriteX -= 50; // move the lion speed from right to left 
            if (lionSpriteX < -100) { // If lion goes off-screen to the left
                lionSpriteX = frameWidth + 100; // reset to start from the right again
            }
            currentLionSpriteIndex = (currentLionSpriteIndex + 1) % lionSpriteImages.length;

            // update Parrot's animation
            if (count >= 25) {
                parrotRetreating = true;
            }

            if (parrotRetreating) {
                parrotSpriteX -= parrotRetreatSpeed; // Move to the LEFT
                if (parrotSpriteX < -parrotSpriteImages[0].getWidth(this) - 10) { // If parrot goes off-screen to the left, then
                    parrotSpriteX = -parrotSpriteImages[0].getWidth(this) - 10; // keep it off-screen!
                }
            } else {
                parrotHoverAngle += parrotHoverSpeed;
                parrotSpriteY = (int) ( parrotHoverOffset*Math.sin(parrotHoverAngle) + 0.4*frameHeight );
                /*
                 https://www.desmos.com/calculator
                 10*sin(x) + 0.4*1080
                 a*sin(x)+0.4*b
                 then add sliders: b doesnt change but a can
                 */
            }
            currentParrotSpriteIndex = (currentParrotSpriteIndex + 1) % parrotSpriteImages.length;

            repaint();

            if (count > 40) { 
                dispose();
            }
        }
    }

    public void update(Graphics g) {
        paint(g);
    }

    public void paint(Graphics g) {
        int width = getWidth();
        int height = getHeight();

        if (offScreenBuffer == null || offScreenBuffer.getWidth() != width || offScreenBuffer.getHeight() != height) {
            offScreenBuffer = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            offScreenGraphics = offScreenBuffer.getGraphics();
        }

        if (backgroundImage != null) {
            offScreenGraphics.drawImage(backgroundImage, 0, 0, width, height, this);
        }

        // Draw the Lion
        if (lionSpriteImages != null && lionSpriteImages.length > 0 && lionSpriteImages[currentLionSpriteIndex] != null) {
            offScreenGraphics.drawImage(lionSpriteImages[currentLionSpriteIndex], lionSpriteX, lionSpriteY, this);
        }

        // Draw the Parrot
        if (parrotSpriteImages != null && parrotSpriteImages.length > 0 && parrotSpriteImages[currentParrotSpriteIndex] != null) {
            offScreenGraphics.drawImage(parrotSpriteImages[currentParrotSpriteIndex], parrotSpriteX, parrotSpriteY, this);
        }

        g.drawImage(offScreenBuffer, 0, 0, this);
    }

    public static void main(String[] args) {
        new LionParrot("Lion and Parrot Animation");
        
    }
}