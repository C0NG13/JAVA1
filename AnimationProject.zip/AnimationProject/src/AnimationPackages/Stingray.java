package AnimationPackages;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class Stingray extends Frame implements Runnable {

    private Image backgroundImage;
    private Image[] spriteImages;
    private int currentSpriteIndex = 0;
    private int spriteChangeDelay = 700; // milliseconds between sprite frames 
    private Thread animator;
    private int spriteX; // sprite start position is set in constructor
    private int spriteY; //  position will be set in constructor
    private int frameWidth;
    private int frameHeight;
    private GraphicsDevice gd;
    private BufferedImage offScreenBuffer;
    private Graphics offScreenGraphics;
    private int count = 0;

    private String backgroundPath = "src/imagesAWT/underwater.jpg"; 
    private String[] spritePaths = {
            "src/imagesAWT/stingray1.jpg", 
            "src/imagesAWT/stingray2.jpg",
            "src/imagesAWT/stingray3.jpg",
            "src/imagesAWT/stingray4.jpg",
            "src/imagesAWT/stingray3.jpg",
            "src/imagesAWT/stingray2.jpg",
            "src/imagesAWT/stingray1.jpg", 
            "src/imagesAWT/stingray2.jpg",
            "src/imagesAWT/stingray3.jpg",
            "src/imagesAWT/stingray4.jpg",
            "src/imagesAWT/stingray1.jpg", 
            "src/imagesAWT/stingray2.jpg",
            "src/imagesAWT/stingray3.jpg"
    };

    public Stingray(String title) {
        super(title);
        try { // use the file paths 
            backgroundImage = ImageIO.read(new File(backgroundPath));
            // iterate through the list of sprite images
            spriteImages = new Image[spritePaths.length];
            for (int i = 0; i < spritePaths.length; i++) {
                spriteImages[i] = ImageIO.read(new File(spritePaths[i]));
            }
        } catch (IOException e) {
            System.err.println("Error loading images: " + e.getMessage()); // prints red error message in the console
            System.exit(1);
        }


        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        gd = ge.getDefaultScreenDevice(); 
        DisplayMode dm = gd.getDisplayMode(); // gets screen details
        setUndecorated(true);
        setSize(dm.getWidth(), dm.getHeight());
        gd.setFullScreenWindow(this); // make animated display full screen

        frameWidth = dm.getWidth();  // this looks repetitive, but it is not
        frameHeight = dm.getHeight(); // remove lines 66 and 67 and the sprite changes veritical location
        
        spriteX = frameWidth + 100; // start off-screen to the right
        spriteY = (int) (frameHeight * 0.7); // position near the bottom (70% of screen height)  

        setVisible(true);

        animator = new Thread(this); // makes a new thread outside of Event Dispatch Thread 
        // ^^^ sets up thread responsible for the animation loop
        
        /*
         Thread(this) is responsible for:
         		controlling the timing of the animation (e.g. how fast the sprite moves across screen)
         		updates the animation (e.g. switching out sprite images)
         		separates animation logic from the Event Dispatch Thread used for the menu
         				This ensures that the animation will not make the menu GUI unresponsive or block it.
         */
        count = 1;
        animator.start();
    }

    public void run() {
        while (count <= 15) { // when we hit the 15th sprite, we are done
            try {
                Thread.sleep(spriteChangeDelay);
                count++;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }

            spriteX -= 170; // speed of sprite moving from right to left 
            if (spriteX < -100) { // If stingray goes off-screen to the left, then
                spriteX = frameWidth + 100; // reset to start from the right again.
            } 
            
            // to demonstrate how the movement works, comment the above three lines and uncomment the below three lines.
            /* 
            spriteX += 200; // speed of sprite moving from LEFT to RIGHT
			if (spriteX > frameWidth + 100) { // If sprite goes off-screen to the right
                spriteX = -100; // Reset to start from the left again
            }
            */
           

            currentSpriteIndex = (currentSpriteIndex + 1) % spriteImages.length;  //increment sprite images by 1
            // the mod operator prevents the index from going beyond the list length
            repaint(); // updating the display
            if (count > 15) {
                dispose(); // exit the animation when we are past the 15th sprite change
            }
        }
    }

    
    public void update(Graphics g) {
        paint(g);
    }

    
    /* 
     The paint method uses image buffering. 
     First the image is painted by the offScreenBuffer.
     Then the off screen image is painted.
     
     */
    public void paint(Graphics g) {
        int width = getWidth();
        int height = getHeight();
        
        // drawing off screen
        if (offScreenBuffer == null || offScreenBuffer.getWidth() != width || offScreenBuffer.getHeight() != height) {
            offScreenBuffer = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            offScreenGraphics = offScreenBuffer.getGraphics();
        }

        if (backgroundImage != null) {
            offScreenGraphics.drawImage(backgroundImage, 0, 0, width, height, this);
        }

        // drawing on screen
        if (spriteImages != null && spriteImages.length > 0 && spriteImages[currentSpriteIndex] != null) {
            offScreenGraphics.drawImage(spriteImages[currentSpriteIndex], spriteX, spriteY, this);
        }

        // drawing the buffered image on the screen
        g.drawImage(offScreenBuffer, 0, 0, this);
    }

    public static void main(String[] args) {
        new Stingray("Stingray Animation");
    }
}
