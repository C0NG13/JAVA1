package AnimationPackages;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class Lion extends Frame implements Runnable {

    private Image backgroundImage;
    private Image[] spriteImages;
    private int currentSpriteIndex = 0;
    private int spriteChangeDelay = 200; 
    private Thread animator;
    private int spriteX; 
    private int spriteY; 
    private int frameWidth;
    private int frameHeight;
    private GraphicsDevice gd;
    private DisplayMode dm;
    private BufferedImage offScreenBuffer;
    private Graphics offScreenGraphics;
    private int count = 0;

    private String backgroundPath = "src/imagesAWT/lionbeach.jpg"; // Changed to underwater.jpg
    private String[] spritePaths = {
            "src/imagesAWT/lioness1.png", 
            "src/imagesAWT/lioness2.png",
            "src/imagesAWT/lioness3.png",
            "src/imagesAWT/lioness4.png",
            "src/imagesAWT/lioness5.png", 
            "src/imagesAWT/lioness6.png",
            "src/imagesAWT/lioness7.png",
            "src/imagesAWT/lioness8.png",
    };

    public Lion(String title) {
        super(title);
        try {
            backgroundImage = ImageIO.read(new File(backgroundPath));
            spriteImages = new Image[spritePaths.length];
            for (int i = 0; i < spritePaths.length; i++) {
                spriteImages[i] = ImageIO.read(new File(spritePaths[i]));
            }
        } catch (IOException e) {
            System.err.println("Error loading images: " + e.getMessage());
            System.exit(1);
        }

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        gd = ge.getDefaultScreenDevice(); 
        DisplayMode dm = gd.getDisplayMode(); // gets screen details
        setUndecorated(true);
        setSize(dm.getWidth(), dm.getHeight());
        gd.setFullScreenWindow(this); // make animated display full screen

        frameWidth = dm.getWidth();
        frameHeight = dm.getHeight();
        spriteX = frameWidth + 100; // Start off-screen to the right
        spriteY = (int) (frameHeight * 0.5); // Position near the bottom (80% of screen height)

        setVisible(true);

        animator = new Thread(this);
        count = 1;
        animator.start();
    }

    public void run() {
        while (count <= 23) {
            try {
                Thread.sleep(spriteChangeDelay);
                count++;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }

            spriteX -= 200; // Move speed of the sprite from right to left (adjust speed here)
            if (spriteX < -100) { // If sprite goes off-screen to the left
                spriteX = frameWidth + 100; // then reset to start from the right again
            }

            currentSpriteIndex = (currentSpriteIndex + 1) % spriteImages.length;
            repaint();
            if (count > 23) {
                dispose();
            }
        }
    }

    public void update(Graphics g) {
        paint(g);
    }

    public void paint(Graphics g) {
        int width = getWidth();
        int height = getHeight();

        if (offScreenBuffer == null || offScreenBuffer.getWidth() != width || offScreenBuffer.getHeight() != height) {
            offScreenBuffer = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            offScreenGraphics = offScreenBuffer.getGraphics();
        }

        if (backgroundImage != null) {
            offScreenGraphics.drawImage(backgroundImage, 0, 0, width, height, this);
        }

        if (spriteImages != null && spriteImages.length > 0 && spriteImages[currentSpriteIndex] != null) {
            offScreenGraphics.drawImage(spriteImages[currentSpriteIndex], spriteX, spriteY, this);
        }

        g.drawImage(offScreenBuffer, 0, 0, this);
    }

    public static void main(String[] args) {
        new Lion("Stingray Animation");
    }
}
