package AnimationPackages;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class Parrot extends Frame implements Runnable {

    private Image backgroundImage;
    private Image[] spriteImages;
    private int currentSpriteIndex = 0;
    private int spriteChangeDelay = 200; // milliseconds between sprite frames (adjust as needed)
    private Thread animator;
    private int spriteX; // Start position will be set in constructor
    private int spriteY; //  position will be set in constructor
    private int frameWidth;
    private int frameHeight;
    private GraphicsDevice gd;
    private DisplayMode dm;
    private BufferedImage offScreenBuffer;
    private Graphics offScreenGraphics;
    private int count = 0;

    private String backgroundPath = "src/imagesAWT/parrotbeach.jpeg"; // Changed to underwater.jpg
    private String[] spritePaths = {
            "src/imagesAWT/parrotess1.png", 
            "src/imagesAWT/parrotess2.png",
            "src/imagesAWT/parrotess3.png",
            "src/imagesAWT/parrotess4.png",
            "src/imagesAWT/parrotess5.png", 
            "src/imagesAWT/parrotess6.png",
            "src/imagesAWT/parrotess7.png",
            "src/imagesAWT/parrotess8.png",
            "src/imagesAWT/parrotess9.png",
            "src/imagesAWT/parrotess10.png",
            
    };

    public Parrot(String title) {
        super(title);
        try {
            backgroundImage = ImageIO.read(new File(backgroundPath));
            spriteImages = new Image[spritePaths.length];
            for (int i = 0; i < spritePaths.length; i++) {
                spriteImages[i] = ImageIO.read(new File(spritePaths[i]));
            }
        } catch (IOException e) {
            System.err.println("Error loading images: " + e.getMessage());
            System.exit(1);
        }

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        gd = ge.getDefaultScreenDevice(); 
        DisplayMode dm = gd.getDisplayMode(); // gets screen details
        setUndecorated(true);
        setSize(dm.getWidth(), dm.getHeight());
        gd.setFullScreenWindow(this); // make animated display full screen

        frameWidth = dm.getWidth();
        frameHeight = dm.getHeight();
        spriteX = - 100; // Start off-screen to the LEFT
        spriteY = (int) (frameHeight * 0.3); // Position near the bottom (30% of screen height)

        setVisible(true);

        animator = new Thread(this);
        count = 1;
        animator.start();
    }

    public void run() {
        while (count <= 21) {
            try {
                Thread.sleep(spriteChangeDelay);
                count++;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }

            spriteX += 200; // Move the parrot from LEFT to RIGHT (adjust speed here)
            if (spriteX > frameWidth + 100) { // If parrot goes off-screen to the right
                spriteX = -100; // then reset to start from the left again
            }

            currentSpriteIndex = (currentSpriteIndex + 1) % spriteImages.length;
            repaint();
            if (count > 21) {
                dispose();
            }
        }
    }

    public void update(Graphics g) {
        paint(g);
    }

    public void paint(Graphics g) {
        int width = getWidth();
        int height = getHeight();

        if (offScreenBuffer == null || offScreenBuffer.getWidth() != width || offScreenBuffer.getHeight() != height) {
            offScreenBuffer = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            offScreenGraphics = offScreenBuffer.getGraphics();
        }

        if (backgroundImage != null) {
            offScreenGraphics.drawImage(backgroundImage, 0, 0, width, height, this);
        }

        if (spriteImages != null && spriteImages.length > 0 && spriteImages[currentSpriteIndex] != null) {
            offScreenGraphics.drawImage(spriteImages[currentSpriteIndex], spriteX, spriteY, this);
        }

        g.drawImage(offScreenBuffer, 0, 0, this);
    }

    public static void main(String[] args) {
        new Parrot("Stingray Animation");
    }
}
