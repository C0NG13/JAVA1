package AnimationPackages;

import java.awt.*;
import java.awt.event.*;

import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

@SuppressWarnings("serial")
public class PenguinNotBuffered extends Frame implements Runnable {

    private Image backgroundImage;
    private Image[] spriteImages;
    private int currentSpriteIndex = 0;
    private int spriteChangeDelay = 100; // milliseconds between sprite frames
    private Thread animator;
    private int count = 0;
    private GraphicsDevice gd;
    private DisplayMode dm;

    private String backgroundPath = "src/imagesAWT/background.png";
    private String[] spritePaths = {
            "src/imagesAWT/penguin1.png",
            "src/imagesAWT/penguin2.png",
            "src/imagesAWT/penguin3.png",
            "src/imagesAWT/penguin4.png",
            "src/imagesAWT/penguin5.png",
            "src/imagesAWT/penguin6.png",
            "src/imagesAWT/penguin7.png",
            "src/imagesAWT/penguin8.png",
            "src/imagesAWT/penguin9.png",
            "src/imagesAWT/penguin10.png",
            "src/imagesAWT/penguin11.png",
            "src/imagesAWT/penguin12.png",
            "src/imagesAWT/penguin13.png",
            "src/imagesAWT/penguin13.png",
            "src/imagesAWT/penguin13.png"

    };

    public PenguinNotBuffered(String title) {
        super(title);
        try {
            backgroundImage = ImageIO.read(new File(backgroundPath));
            spriteImages = new Image[spritePaths.length];
            for (int i = 0; i < spritePaths.length; i++) {
                spriteImages[i] = ImageIO.read(new File(spritePaths[i]));
            }
        } catch (IOException e) {
            System.err.println("Error loading images: " + e.getMessage());
            System.exit(1);
        }

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {

                System.exit(0);
            }
        });

        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        gd = ge.getDefaultScreenDevice(); 
        DisplayMode dm = gd.getDisplayMode(); // gets screen details
        setUndecorated(true);
        setSize(dm.getWidth(), dm.getHeight());
        gd.setFullScreenWindow(this); // make animated display full screen

        setVisible(true);

        animator = new Thread(this);
        count = 1;
        animator.start();
    }

    public void run() {
        while (count <= 30) {
            try {
                Thread.sleep(spriteChangeDelay);
                count++;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();

            }
            currentSpriteIndex = (currentSpriteIndex + 1) % spriteImages.length;
            repaint();
        }
        if (count > 30) {
            dispose();
        }
    }

    public void paint(Graphics g) {
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }

        if (spriteImages != null && spriteImages.length > 0 && spriteImages[currentSpriteIndex] != null) {
            // adjust the position of the sprite as needed
            int spriteX = getWidth() / 2 - spriteImages[currentSpriteIndex].getWidth(this) / 2;
            int spriteY = getHeight() / 2 - spriteImages[currentSpriteIndex].getHeight(this) / 2;
            g.drawImage(spriteImages[currentSpriteIndex], spriteX, spriteY, this);
        }
    }

    public static void main(String[] args) {
        new PenguinNotBuffered("AWT Sprite Example");
    }
}